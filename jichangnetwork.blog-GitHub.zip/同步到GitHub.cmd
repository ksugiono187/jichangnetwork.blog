@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo 机场网络：检查并同步到指定 GitHub 仓库。
where git >nul 2>nul
if errorlevel 1 goto missinggit
where node >nul 2>nul
if errorlevel 1 goto missingnode
call npm run build
if errorlevel 1 goto failed
call npm run check
if errorlevel 1 goto failed
git fetch origin
if errorlevel 1 goto failed
git rev-parse --verify HEAD >nul 2>nul
if not errorlevel 1 goto stage
git show-ref --verify --quiet refs/remotes/origin/main
if errorlevel 1 goto stage
echo 首次同步：读取远端历史，保留本地全部网站文件。
git reset --mixed origin/main
if errorlevel 1 goto failed
:stage
git add --all
if errorlevel 1 goto failed
git diff --cached --quiet
if errorlevel 2 goto failed
if not errorlevel 1 goto push
git commit -m "Update jichangnetwork.blog website and content"
if errorlevel 1 goto failed
:push
git push -u origin main
if errorlevel 1 goto failed
echo.
echo GitHub 同步完成。域名和 Pages 是否上线仍以实际部署状态为准。
pause
exit /b 0
:missinggit
echo 请先安装 Git，然后重新运行。
pause
exit /b 1
:missingnode
echo 请先安装 Node.js 22 或更新版本，然后重新运行。
pause
exit /b 1
:failed
echo.
echo 同步未完成，请保留上方错误信息。此脚本不会强制推送或覆盖远端。
echo 如出现 GitHub 登录提示，请仅在 GitHub 官方登录窗口完成授权。
pause
exit /b 1
